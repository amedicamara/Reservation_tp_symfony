<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_cc968665991ccae1d97eee810bb72649 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" href=\"data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 128 128%22><text y=%221.2em%22 font-size=%2296%22>⚫️</text></svg>\">
        ";
        // line 8
        echo "        ";
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 25
        echo "
        ";
        // line 26
        $this->displayBlock('javascripts', $context, $blocks);
        // line 47
        echo "    </head>
    <body>
<div class=\"pre-loader\">
\t\t<div class=\"pre-loader-box\">
\t\t\t<div class=\"loader-logo\"><img src=\"vendors/images/deskapp-logo.svg\" alt=\"\"></div>
\t\t\t<div class='loader-progress' id=\"progress_div\">
\t\t\t\t<div class='bar' id='bar1'></div>
\t\t\t</div>
\t\t\t<div class='percent' id='percent1'>0%</div>
\t\t\t<div class=\"loading-text\">
\t\t\t\tLoading...
\t\t\t</div>
\t\t</div>
\t</div>

\t<div class=\"header\">
\t\t<div class=\"header-left\">
\t\t\t<div class=\"menu-icon dw dw-menu\"></div>
\t\t\t<div class=\"search-toggle-icon dw dw-search2\" data-toggle=\"header_search\"></div>
\t\t\t<div class=\"header-search\">
\t\t\t\t<form>
\t\t\t\t\t<div class=\"form-group mb-0\">
\t\t\t\t\t\t<i class=\"dw dw-search2 search-icon\"></i>
\t\t\t\t\t\t<input type=\"text\" class=\"form-control search-input\" placeholder=\"Search Here\">
\t\t\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t\t\t<a class=\"dropdown-toggle no-arrow\" href=\"#\" role=\"button\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t\t<i class=\"ion-arrow-down-c\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"dropdown-menu dropdown-menu-right\">
\t\t\t\t\t\t\t\t<div class=\"form-group row\">
\t\t\t\t\t\t\t\t\t<label class=\"col-sm-12 col-md-2 col-form-label\">From</label>
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-10\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-sm form-control-line\" type=\"text\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group row\">
\t\t\t\t\t\t\t\t\t<label class=\"col-sm-12 col-md-2 col-form-label\">To</label>
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-10\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-sm form-control-line\" type=\"text\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group row\">
\t\t\t\t\t\t\t\t\t<label class=\"col-sm-12 col-md-2 col-form-label\">Subject</label>
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-10\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-sm form-control-line\" type=\"text\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"text-right\">
\t\t\t\t\t\t\t\t\t<button class=\"btn btn-primary\">Search</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"header-right\">
\t\t\t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a href=\"";
        // line 106
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        echo "\" class=\"dropdown-toggle no-arrow\" href=\"javascript:;\" data-toggle=\"right-sidebar\">
\t\t\t\t\tHOME
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>

      \t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a class=\"dropdown-toggle no-arrow\" href=\"javascript:;\" data-toggle=\"right-sidebar\">
\t\t\t\t\tABOUT US
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>

      \t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a href=\"";
        // line 122
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
        echo "\" class=\"dropdown-toggle no-arrow\" href=\"javascript:;\" data-toggle=\"right-sidebar\">
\t\t\t\t\tDECONNEXION
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>

      
\t\t\t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a href=\"";
        // line 131
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_reserve");
        echo "\" class=\"dropdown-toggle no-arrow\"  role=\"button\" >
\t\t\t\t\tRESERVATION
\t\t\t\t\t
\t\t\t\t\t</a>
\t\t\t\t
\t\t\t\t\t</div>

          
\t\t\t\t</div>
\t\t\t</div>
\t\t
\t\t\t\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"github-link\">
\t\t\t\t<a href=\"https://github.com/dropways/deskapp\" target=\"_blank\"><img src=\"vendors/images/github.svg\" alt=\"\"></a>
\t\t\t</div>
\t\t</div>
\t</div>

\t


\t<div class=\"left-side-bar\">
\t\t<div class=\"brand-logo\">
\t\t\t<a href=\"index.html\">
\t\t\t\t<img src=\"vendors/images/deskapp-logo.svg\" alt=\"\" class=\"dark-logo\">
\t\t\t\t<img src=\"vendors/images/deskapp-logo-white.svg\" alt=\"\" class=\"light-logo\">
\t\t\t</a>
\t\t\t<div class=\"close-sidebar\" data-toggle=\"left-sidebar-close\">
\t\t\t\t<i class=\"ion-close-round\"></i>
\t\t\t</div>
\t\t</div>

        ";
        // line 166
        $this->displayBlock('body', $context, $blocks);
        // line 167
        echo "    </body>
</html>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "           <!-- Site favicon -->
\t<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"vendors/images/apple-touch-icon.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"vendors/images/favicon-32x32.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"vendors/images/favicon-16x16.png\">

\t<!-- Mobile Specific Metas -->
\t

\t<!-- Google Font -->
\t<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap\" rel=\"stylesheet\">
\t<!-- CSS -->
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/core.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/icon-font.min.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"src/plugins/jvectormap/jquery-jvectormap-2.0.3.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/style.css\">
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 26
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 27
        echo "          \t<!-- js -->
\t<script src=\"vendors/scripts/core.js\"></script>
\t<script src=\"vendors/scripts/script.min.js\"></script>
\t<script src=\"vendors/scripts/process.js\"></script>
\t<script src=\"vendors/scripts/layout-settings.js\"></script>
\t<script src=\"src/plugins/jQuery-Knob-master/jquery.knob.min.js\"></script>
\t<script src=\"src/plugins/highcharts-6.0.7/code/highcharts.js\"></script>
\t<script src=\"src/plugins/highcharts-6.0.7/code/highcharts-more.js\"></script>
\t<script src=\"src/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js\"></script>
\t<script src=\"src/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>
\t<script src=\"vendors/scripts/dashboard2.js\"></script>
    \t<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-119386393-1\"></script>
\t<script>
\t\twindow.dataLayer = window.dataLayer || [];
\t\tfunction gtag(){dataLayer.push(arguments);}
\t\tgtag('js', new Date());

\t\tgtag('config', 'UA-119386393-1');
\t</script>
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 166
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  303 => 166,  274 => 27,  264 => 26,  239 => 9,  229 => 8,  210 => 5,  198 => 167,  196 => 166,  158 => 131,  146 => 122,  127 => 106,  66 => 47,  64 => 26,  61 => 25,  58 => 8,  53 => 5,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>{% block title %}Welcome!{% endblock %}</title>
        <link rel=\"icon\" href=\"data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 128 128%22><text y=%221.2em%22 font-size=%2296%22>⚫️</text></svg>\">
        {# Run `composer require symfony/webpack-encore-bundle` to start using Symfony UX #}
        {% block stylesheets %}
           <!-- Site favicon -->
\t<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"vendors/images/apple-touch-icon.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"vendors/images/favicon-32x32.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"vendors/images/favicon-16x16.png\">

\t<!-- Mobile Specific Metas -->
\t

\t<!-- Google Font -->
\t<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap\" rel=\"stylesheet\">
\t<!-- CSS -->
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/core.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/icon-font.min.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"src/plugins/jvectormap/jquery-jvectormap-2.0.3.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/style.css\">
        {% endblock %}

        {% block javascripts %}
          \t<!-- js -->
\t<script src=\"vendors/scripts/core.js\"></script>
\t<script src=\"vendors/scripts/script.min.js\"></script>
\t<script src=\"vendors/scripts/process.js\"></script>
\t<script src=\"vendors/scripts/layout-settings.js\"></script>
\t<script src=\"src/plugins/jQuery-Knob-master/jquery.knob.min.js\"></script>
\t<script src=\"src/plugins/highcharts-6.0.7/code/highcharts.js\"></script>
\t<script src=\"src/plugins/highcharts-6.0.7/code/highcharts-more.js\"></script>
\t<script src=\"src/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js\"></script>
\t<script src=\"src/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>
\t<script src=\"vendors/scripts/dashboard2.js\"></script>
    \t<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-119386393-1\"></script>
\t<script>
\t\twindow.dataLayer = window.dataLayer || [];
\t\tfunction gtag(){dataLayer.push(arguments);}
\t\tgtag('js', new Date());

\t\tgtag('config', 'UA-119386393-1');
\t</script>
        {% endblock %}
    </head>
    <body>
<div class=\"pre-loader\">
\t\t<div class=\"pre-loader-box\">
\t\t\t<div class=\"loader-logo\"><img src=\"vendors/images/deskapp-logo.svg\" alt=\"\"></div>
\t\t\t<div class='loader-progress' id=\"progress_div\">
\t\t\t\t<div class='bar' id='bar1'></div>
\t\t\t</div>
\t\t\t<div class='percent' id='percent1'>0%</div>
\t\t\t<div class=\"loading-text\">
\t\t\t\tLoading...
\t\t\t</div>
\t\t</div>
\t</div>

\t<div class=\"header\">
\t\t<div class=\"header-left\">
\t\t\t<div class=\"menu-icon dw dw-menu\"></div>
\t\t\t<div class=\"search-toggle-icon dw dw-search2\" data-toggle=\"header_search\"></div>
\t\t\t<div class=\"header-search\">
\t\t\t\t<form>
\t\t\t\t\t<div class=\"form-group mb-0\">
\t\t\t\t\t\t<i class=\"dw dw-search2 search-icon\"></i>
\t\t\t\t\t\t<input type=\"text\" class=\"form-control search-input\" placeholder=\"Search Here\">
\t\t\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t\t\t<a class=\"dropdown-toggle no-arrow\" href=\"#\" role=\"button\" data-toggle=\"dropdown\">
\t\t\t\t\t\t\t\t<i class=\"ion-arrow-down-c\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t<div class=\"dropdown-menu dropdown-menu-right\">
\t\t\t\t\t\t\t\t<div class=\"form-group row\">
\t\t\t\t\t\t\t\t\t<label class=\"col-sm-12 col-md-2 col-form-label\">From</label>
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-10\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-sm form-control-line\" type=\"text\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group row\">
\t\t\t\t\t\t\t\t\t<label class=\"col-sm-12 col-md-2 col-form-label\">To</label>
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-10\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-sm form-control-line\" type=\"text\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"form-group row\">
\t\t\t\t\t\t\t\t\t<label class=\"col-sm-12 col-md-2 col-form-label\">Subject</label>
\t\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-10\">
\t\t\t\t\t\t\t\t\t\t<input class=\"form-control form-control-sm form-control-line\" type=\"text\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"text-right\">
\t\t\t\t\t\t\t\t\t<button class=\"btn btn-primary\">Search</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"header-right\">
\t\t\t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a href=\"{{path(\"app_home\")}}\" class=\"dropdown-toggle no-arrow\" href=\"javascript:;\" data-toggle=\"right-sidebar\">
\t\t\t\t\tHOME
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>

      \t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a class=\"dropdown-toggle no-arrow\" href=\"javascript:;\" data-toggle=\"right-sidebar\">
\t\t\t\t\tABOUT US
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>

      \t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a href=\"{{path(\"app_login\")}}\" class=\"dropdown-toggle no-arrow\" href=\"javascript:;\" data-toggle=\"right-sidebar\">
\t\t\t\t\tDECONNEXION
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>

      
\t\t\t<div class=\"dashboard-setting user-notification\">
\t\t\t\t<div class=\"dropdown\">
\t\t\t\t\t<a href=\"{{path(\"app_reserve\")}}\" class=\"dropdown-toggle no-arrow\"  role=\"button\" >
\t\t\t\t\tRESERVATION
\t\t\t\t\t
\t\t\t\t\t</a>
\t\t\t\t
\t\t\t\t\t</div>

          
\t\t\t\t</div>
\t\t\t</div>
\t\t
\t\t\t\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"github-link\">
\t\t\t\t<a href=\"https://github.com/dropways/deskapp\" target=\"_blank\"><img src=\"vendors/images/github.svg\" alt=\"\"></a>
\t\t\t</div>
\t\t</div>
\t</div>

\t


\t<div class=\"left-side-bar\">
\t\t<div class=\"brand-logo\">
\t\t\t<a href=\"index.html\">
\t\t\t\t<img src=\"vendors/images/deskapp-logo.svg\" alt=\"\" class=\"dark-logo\">
\t\t\t\t<img src=\"vendors/images/deskapp-logo-white.svg\" alt=\"\" class=\"light-logo\">
\t\t\t</a>
\t\t\t<div class=\"close-sidebar\" data-toggle=\"left-sidebar-close\">
\t\t\t\t<i class=\"ion-close-round\"></i>
\t\t\t</div>
\t\t</div>

        {% block body %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\cours\\reserveApp\\templates\\base.html.twig");
    }
}
