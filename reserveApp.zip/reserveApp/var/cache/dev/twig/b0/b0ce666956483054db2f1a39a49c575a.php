<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* symfony/inscription.html.twig */
class __TwigTemplate_5a4a06015e7f0e3ed516528e901af3e8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "symfony/inscription.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "symfony/inscription.html.twig"));

        // line 1
        echo "
<!DOCTYPE html>
<html>
<head>
\t<!-- Basic Page Info -->
\t<meta charset=\"utf-8\">
\t<title>Inscription</title>

\t<!-- Site favicon -->
\t<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"vendors/images/apple-touch-icon.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"vendors/images/favicon-32x32.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"vendors/images/favicon-16x16.png\">

\t<!-- Mobile Specific Metas -->
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">

\t<!-- Google Font -->
\t<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap\" rel=\"stylesheet\">
\t<!-- CSS -->
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/core.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/icon-font.min.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/style.css\">

\t<!-- Global site tag (gtag.js) - Google Analytics -->
\t<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-119386393-1\"></script>
\t<script>
\t\twindow.dataLayer = window.dataLayer || [];
\t\tfunction gtag(){dataLayer.push(arguments);}
\t\tgtag('js', new Date());

\t\tgtag('config', 'UA-119386393-1');
\t</script>
</head>
<body class=\"login-page\">
\t<div class=\"login-header box-shadow\">
\t\t<div class=\"container-fluid d-flex justify-content-between align-items-center\">
\t\t\t<div class=\"brand-logo\">
\t\t\t\t<a href=\"login.html\">
\t\t\t\t\t<img src=\"vendors/images/deskapp-logo.svg\" alt=\"\">
\t\t\t\t</a>
\t\t\t</div>
\t\t\t<div class=\"login-menu\">
\t\t\t\t<ul>
\t\t\t\t\t<li><a href=\"";
        // line 44
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
        echo "\">Se Connecter</a></li>
\t\t\t\t</ul>
\t\t\t</div>
\t\t</div>
\t</div>
\t<div class=\"login-wrap d-flex align-items-center flex-wrap justify-content-center\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row align-items-center\">
\t\t\t\t<div class=\"col-md-6 col-lg-7\">
\t\t\t\t\t<img src=\"vendors/images/login-page-img.png\" alt=\"\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-6 col-lg-5\">
\t\t\t\t\t<div class=\"login-box bg-white box-shadow border-radius-10\">
\t\t\t\t\t\t<div class=\"login-title\">
\t\t\t\t\t\t\t<h2 class=\"text-center text-primary\">INSCRIPTION</h2>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<form>
\t\t\t\t\t\t\t<div class=\"select-role\">
\t\t\t\t\t\t\t\t<div class=\"btn-group btn-group-toggle\" data-toggle=\"buttons\">
\t\t\t\t\t\t\t\t\t<label class=\"btn active\">
\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"options\" id=\"admin\">
\t\t\t\t\t\t\t\t\t\t<div class=\"icon\"><img src=\"vendors/images/briefcase.svg\" class=\"svg\" alt=\"\"></div>
\t\t\t\t\t\t\t\t\t\t<span>I'm</span>
\t\t\t\t\t\t\t\t\t\tManager
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<label class=\"btn\">
\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"options\" id=\"user\">
\t\t\t\t\t\t\t\t\t\t<div class=\"icon\"><img src=\"vendors/images/person.svg\" class=\"svg\" alt=\"\"></div>
\t\t\t\t\t\t\t\t\t\t<span>I'm</span>
\t\t\t\t\t\t\t\t\t\tEmployee
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-group custom\">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control form-control-lg\" placeholder=\"Username\">
\t\t\t\t\t\t\t\t<div class=\"input-group-append custom\">
\t\t\t\t\t\t\t\t\t<span class=\"input-group-text\"><i class=\"icon-copy dw dw-user1\"></i></span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-group custom\">
\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control form-control-lg\" placeholder=\"**********\">
\t\t\t\t\t\t\t\t<div class=\"input-group-append custom\">
\t\t\t\t\t\t\t\t\t<span class=\"input-group-text\"><i class=\"dw dw-padlock1\"></i></span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row pb-30\">
\t\t\t\t\t\t\t\t<div class=\"col-6\">
\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox\">
\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customCheck1\">
\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customCheck1\">Remember</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-6\">
\t\t\t\t\t\t\t\t\t<div class=\"forgot-password\"><a href=\"forgot-password.html\">Forgot Password</a></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group mb-0\">
\t\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\t\t\tuse code for form submit
\t\t\t\t\t\t\t\t\t\t\t<input class=\"btn btn-primary btn-lg btn-block\" type=\"submit\" value=\"Sign In\">
\t\t\t\t\t\t\t\t\t\t-->
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-primary btn-lg btn-block\" href=\"";
        // line 107
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        echo "\">S'incrire</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"font-16 weight-600 pt-10 pb-10 text-center\" data-color=\"#707373\">OR</div>
\t\t\t\t\t\t\t\t\t<div class=\"input-group mb-0\">
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-primary btn-lg btn-block\" href=\"register.html\">Register To Create Account</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- js -->
\t<script src=\"vendors/scripts/core.js\"></script>
\t<script src=\"vendors/scripts/script.min.js\"></script>
\t<script src=\"vendors/scripts/process.js\"></script>
\t<script src=\"vendors/scripts/layout-settings.js\"></script>
</body>
</html>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "symfony/inscription.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 107,  88 => 44,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
<!DOCTYPE html>
<html>
<head>
\t<!-- Basic Page Info -->
\t<meta charset=\"utf-8\">
\t<title>Inscription</title>

\t<!-- Site favicon -->
\t<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"vendors/images/apple-touch-icon.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"32x32\" href=\"vendors/images/favicon-32x32.png\">
\t<link rel=\"icon\" type=\"image/png\" sizes=\"16x16\" href=\"vendors/images/favicon-16x16.png\">

\t<!-- Mobile Specific Metas -->
\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">

\t<!-- Google Font -->
\t<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap\" rel=\"stylesheet\">
\t<!-- CSS -->
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/core.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/icon-font.min.css\">
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"vendors/styles/style.css\">

\t<!-- Global site tag (gtag.js) - Google Analytics -->
\t<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-119386393-1\"></script>
\t<script>
\t\twindow.dataLayer = window.dataLayer || [];
\t\tfunction gtag(){dataLayer.push(arguments);}
\t\tgtag('js', new Date());

\t\tgtag('config', 'UA-119386393-1');
\t</script>
</head>
<body class=\"login-page\">
\t<div class=\"login-header box-shadow\">
\t\t<div class=\"container-fluid d-flex justify-content-between align-items-center\">
\t\t\t<div class=\"brand-logo\">
\t\t\t\t<a href=\"login.html\">
\t\t\t\t\t<img src=\"vendors/images/deskapp-logo.svg\" alt=\"\">
\t\t\t\t</a>
\t\t\t</div>
\t\t\t<div class=\"login-menu\">
\t\t\t\t<ul>
\t\t\t\t\t<li><a href=\"{{path(\"app_login\")}}\">Se Connecter</a></li>
\t\t\t\t</ul>
\t\t\t</div>
\t\t</div>
\t</div>
\t<div class=\"login-wrap d-flex align-items-center flex-wrap justify-content-center\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row align-items-center\">
\t\t\t\t<div class=\"col-md-6 col-lg-7\">
\t\t\t\t\t<img src=\"vendors/images/login-page-img.png\" alt=\"\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-md-6 col-lg-5\">
\t\t\t\t\t<div class=\"login-box bg-white box-shadow border-radius-10\">
\t\t\t\t\t\t<div class=\"login-title\">
\t\t\t\t\t\t\t<h2 class=\"text-center text-primary\">INSCRIPTION</h2>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<form>
\t\t\t\t\t\t\t<div class=\"select-role\">
\t\t\t\t\t\t\t\t<div class=\"btn-group btn-group-toggle\" data-toggle=\"buttons\">
\t\t\t\t\t\t\t\t\t<label class=\"btn active\">
\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"options\" id=\"admin\">
\t\t\t\t\t\t\t\t\t\t<div class=\"icon\"><img src=\"vendors/images/briefcase.svg\" class=\"svg\" alt=\"\"></div>
\t\t\t\t\t\t\t\t\t\t<span>I'm</span>
\t\t\t\t\t\t\t\t\t\tManager
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t<label class=\"btn\">
\t\t\t\t\t\t\t\t\t\t<input type=\"radio\" name=\"options\" id=\"user\">
\t\t\t\t\t\t\t\t\t\t<div class=\"icon\"><img src=\"vendors/images/person.svg\" class=\"svg\" alt=\"\"></div>
\t\t\t\t\t\t\t\t\t\t<span>I'm</span>
\t\t\t\t\t\t\t\t\t\tEmployee
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-group custom\">
\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control form-control-lg\" placeholder=\"Username\">
\t\t\t\t\t\t\t\t<div class=\"input-group-append custom\">
\t\t\t\t\t\t\t\t\t<span class=\"input-group-text\"><i class=\"icon-copy dw dw-user1\"></i></span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"input-group custom\">
\t\t\t\t\t\t\t\t<input type=\"password\" class=\"form-control form-control-lg\" placeholder=\"**********\">
\t\t\t\t\t\t\t\t<div class=\"input-group-append custom\">
\t\t\t\t\t\t\t\t\t<span class=\"input-group-text\"><i class=\"dw dw-padlock1\"></i></span>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row pb-30\">
\t\t\t\t\t\t\t\t<div class=\"col-6\">
\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox\">
\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customCheck1\">
\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customCheck1\">Remember</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-6\">
\t\t\t\t\t\t\t\t\t<div class=\"forgot-password\"><a href=\"forgot-password.html\">Forgot Password</a></div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t\t\t\t<div class=\"input-group mb-0\">
\t\t\t\t\t\t\t\t\t\t<!--
\t\t\t\t\t\t\t\t\t\t\tuse code for form submit
\t\t\t\t\t\t\t\t\t\t\t<input class=\"btn btn-primary btn-lg btn-block\" type=\"submit\" value=\"Sign In\">
\t\t\t\t\t\t\t\t\t\t-->
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-primary btn-lg btn-block\" href=\"{{path(\"app_home\")}}\">S'incrire</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"font-16 weight-600 pt-10 pb-10 text-center\" data-color=\"#707373\">OR</div>
\t\t\t\t\t\t\t\t\t<div class=\"input-group mb-0\">
\t\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-primary btn-lg btn-block\" href=\"register.html\">Register To Create Account</a>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- js -->
\t<script src=\"vendors/scripts/core.js\"></script>
\t<script src=\"vendors/scripts/script.min.js\"></script>
\t<script src=\"vendors/scripts/process.js\"></script>
\t<script src=\"vendors/scripts/layout-settings.js\"></script>
</body>
</html>", "symfony/inscription.html.twig", "C:\\xampp\\htdocs\\cours\\reserveApp\\templates\\symfony\\inscription.html.twig");
    }
}
